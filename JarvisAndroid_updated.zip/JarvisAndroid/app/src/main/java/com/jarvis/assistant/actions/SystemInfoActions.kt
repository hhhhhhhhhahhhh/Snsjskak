package com.jarvis.assistant.actions

import android.app.ActivityManager
import android.content.Context
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SystemInfoActions {

    fun query(context: Context, kind: String): String {
        return when (kind.lowercase()) {
            "battery", "pil" -> battery(context)
            "ram", "memory" -> ram(context)
            "disk", "storage" -> storage()
            "time", "saat" -> time()
            else -> "${battery(context)}\n${ram(context)}\n${storage()}\n${time()}"
        }
    }

    private fun battery(context: Context): String {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = bm.isCharging
        return "Pil: %$pct${if (charging) " (şarj oluyor)" else ""}"
    }

    private fun ram(context: Context): String {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val totalGb = info.totalMem / 1024.0 / 1024.0 / 1024.0
        val availGb = info.availMem / 1024.0 / 1024.0 / 1024.0
        val usedGb = totalGb - availGb
        return "RAM: %.1f GB / %.1f GB kullanılıyor".format(usedGb, totalGb)
    }

    private fun storage(): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        val totalGb = stat.totalBytes / 1024.0 / 1024.0 / 1024.0
        val freeGb = stat.availableBytes / 1024.0 / 1024.0 / 1024.0
        val usedGb = totalGb - freeGb
        return "Depolama: %.1f GB / %.1f GB kullanılıyor".format(usedGb, totalGb)
    }

    private fun time(): String {
        val fmt = SimpleDateFormat("HH:mm, d MMMM yyyy", Locale("tr"))
        return "Şu an: ${fmt.format(Date())}"
    }
}
