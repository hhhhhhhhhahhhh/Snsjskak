package com.jarvis.assistant.actions

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * "Ekranı analiz et" (analyze_screen) sırasında kısa süreliğine çalışan
 * foreground servis. Android 14+ (UPSIDE_DOWN_CAKE), MediaProjection
 * kullanılırken "mediaProjection" tipinde bir foreground service çalışıyor
 * olmasını zorunlu kılar; bu servis sadece bu şartı karşılamak için var —
 * tek bir kare yakalayıp sonucu [ScreenCaptureResultHolder]'a yazar yazmaz
 * kendini kapatır (genelde 1 saniyeden kısa sürer).
 */
class ScreenCaptureService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundWithNotification()

        Thread {
            val base64 = try {
                ScreenCaptureManager.captureOnceBlocking(applicationContext)
            } catch (e: Exception) {
                null
            }
            ScreenCaptureResultHolder.deliver(base64)
            stopSelf()
        }.start()

        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification() {
        val channelId = "jarvis_screen_capture_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Ekran analizi", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("JARVIS ekranı analiz ediyor")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this, 1002, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(1002, notification)
        }
    }

    companion object {
        fun start(context: Context) {
            context.startForegroundService(Intent(context, ScreenCaptureService::class.java))
        }
    }
}
