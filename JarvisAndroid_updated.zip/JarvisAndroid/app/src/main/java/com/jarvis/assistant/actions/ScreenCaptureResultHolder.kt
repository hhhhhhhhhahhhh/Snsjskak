package com.jarvis.assistant.actions

import android.content.Context
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * ActionRouter'ın senkron "execute()" çağrısı ile ScreenCaptureService'in
 * asenkron (foreground service içinde ayrı thread) yakalama işlemi arasında
 * basit bir köprü. Aynı anda tek bir yakalama işlemi desteklenir.
 */
object ScreenCaptureResultHolder {
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var result: String? = null

    @Synchronized
    fun awaitNext(context: Context, timeoutMs: Long = 6000): String? {
        val currentLatch = CountDownLatch(1)
        latch = currentLatch
        result = null
        ScreenCaptureService.start(context)
        currentLatch.await(timeoutMs, TimeUnit.MILLISECONDS)
        return result
    }

    /** ScreenCaptureService, yakalama bitince (başarılı ya da başarısız) burayı çağırır. */
    fun deliver(base64: String?) {
        result = base64
        latch?.countDown()
    }
}
