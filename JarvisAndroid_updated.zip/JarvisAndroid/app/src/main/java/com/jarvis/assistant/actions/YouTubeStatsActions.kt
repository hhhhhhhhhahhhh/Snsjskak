package com.jarvis.assistant.actions

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * Masaüstü sürümündeki youtube_stats.py mantığının Android karşılığı.
 * YouTube Data API v3 kullanır — ücretsiz ama bir API anahtarı gerekir
 * (Google Cloud Console → "YouTube Data API v3" → Kimlik Bilgileri →
 * API anahtarı oluştur). Weather/Open-Meteo'nun aksine bu servis anahtarsız
 * çalışmıyor, bu yüzden Config'e ayrı bir alan eklendi.
 */
object YouTubeStatsActions {

    private val client = OkHttpClient()

    fun getChannelStats(apiKey: String?, channelQuery: String): String {
        if (apiKey.isNullOrBlank()) {
            return "YouTube istatistikleri için bir YouTube Data API anahtarı gerekiyor. " +
                "Google Cloud Console'dan ücretsiz oluşturup ayarlara ekleyebilirsin."
        }
        return try {
            val channelId = resolveChannelId(apiKey, channelQuery)
                ?: return "\"$channelQuery\" adında bir YouTube kanalı bulunamadı."

            val url = "https://www.googleapis.com/youtube/v3/channels" +
                "?part=statistics,snippet&id=$channelId&key=$apiKey"
            val response = client.newCall(Request.Builder().url(url).build()).execute()
            val body = response.body?.string() ?: return "İstatistikler alınamadı."
            val json = JSONObject(body)
            val items = json.optJSONArray("items")
            if (items == null || items.length() == 0) return "Kanal bulunamadı."

            val item = items.getJSONObject(0)
            val title = item.getJSONObject("snippet").getString("title")
            val stats = item.getJSONObject("statistics")
            val subs = stats.optString("subscriberCount", "gizli")
            val views = stats.optString("viewCount", "bilinmiyor")
            val videos = stats.optString("videoCount", "bilinmiyor")

            "$title: $subs abone, $views toplam görüntülenme, $videos video."
        } catch (e: Exception) {
            "YouTube istatistikleri alınırken hata oluştu: ${e.message}"
        }
    }

    /** Kanal adını veya @handle'ını gerçek channelId'ye çevirir. */
    private fun resolveChannelId(apiKey: String, query: String): String? {
        // Önce @handle olarak dene (YouTube Data API v3'ün forHandle parametresi)
        if (query.startsWith("@")) {
            val handleUrl = "https://www.googleapis.com/youtube/v3/channels" +
                "?part=id&forHandle=${URLEncoder.encode(query.removePrefix("@"), "UTF-8")}&key=$apiKey"
            val resp = client.newCall(Request.Builder().url(handleUrl).build()).execute()
            val body = resp.body?.string()
            if (body != null) {
                val items = JSONObject(body).optJSONArray("items")
                if (items != null && items.length() > 0) {
                    return items.getJSONObject(0).getString("id")
                }
            }
        }

        // Yoksa serbest metin aramasıyla en alakalı kanalı bul
        val encoded = URLEncoder.encode(query, "UTF-8")
        val searchUrl = "https://www.googleapis.com/youtube/v3/search" +
            "?part=snippet&type=channel&q=$encoded&maxResults=1&key=$apiKey"
        val resp = client.newCall(Request.Builder().url(searchUrl).build()).execute()
        val body = resp.body?.string() ?: return null
        val items = JSONObject(body).optJSONArray("items")
        if (items == null || items.length() == 0) return null
        return items.getJSONObject(0).getJSONObject("id").getString("channelId")
    }
}
