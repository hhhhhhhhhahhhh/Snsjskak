package com.jarvis.assistant.ai

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * "Ekran analizi" (analyze_screen) için ayrı, tek seferlik görsel sorgu
 * istemcisi. GroqClient'ın kullandığı metin modeli (openai/gpt-oss-120b)
 * görsel giriş kabul etmiyor, bu yüzden Groq'un multimodal modeli kullanılır.
 *
 * Groq'un multimodal model listesi sık değişiyor (llama-4-scout ve
 * llama-3.3-70b-versatile Haziran 2026'da kullanımdan kaldırıldı) — güncel
 * liste için https://console.groq.com/docs/vision adresine bak.
 */
object GroqVisionClient {

    private const val VISION_MODEL = "qwen/qwen3.6-27b"
    private const val ENDPOINT = "https://api.groq.com/openai/v1/chat/completions"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .build()

    fun analyzeImage(apiKey: String, base64Jpeg: String, question: String): String {
        return try {
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", question))
                .put(
                    JSONObject().put("type", "image_url").put(
                        "image_url",
                        JSONObject().put("url", "data:image/jpeg;base64,$base64Jpeg")
                    )
                )

            val body = JSONObject()
                .put("model", VISION_MODEL)
                .put(
                    "messages",
                    JSONArray().put(JSONObject().put("role", "user").put("content", content))
                )

            val request = Request.Builder()
                .url(ENDPOINT)
                .addHeader("Authorization", "Bearer $apiKey")
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) return "Ekran analizi başarısız oldu: $text"
                val json = JSONObject(text)
                json.optJSONArray("choices")?.optJSONObject(0)
                    ?.optJSONObject("message")?.optString("content")
                    ?: "Ekran analiz edilemedi."
            }
        } catch (e: Exception) {
            "Ekran analizi sırasında hata oluştu: ${e.message}"
        }
    }
}
