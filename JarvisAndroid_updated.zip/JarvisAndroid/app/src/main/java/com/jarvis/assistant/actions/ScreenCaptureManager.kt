package com.jarvis.assistant.actions

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Android karşılığı olan "ekran analizi" (analyze_screen) özelliği için
 * MediaProjection tabanlı ekran görüntüsü yakalayıcı.
 *
 * Masaüstü sürümünde bu, ekran görüntüsü alıp doğrudan Gemini Vision'a
 * gönderiyordu. Android'de aynı şeyi yapmak için kullanıcıdan BİR KEZ
 * "ekranı kaydet/yayınla" izni almak gerekiyor (MediaProjection). İzin bir
 * kere verildikten sonra, uygulama süreci canlı kaldığı sürece tekrar
 * sorulmaz.
 *
 * Not: Android 14+ (UPSIDE_DOWN_CAKE) bu API'yi kullanırken "mediaProjection"
 * tipinde bir foreground service çalışıyor olmasını zorunlu kılar; bu yüzden
 * gerçek yakalama işlemi [ScreenCaptureService] içinden tetiklenir.
 */
object ScreenCaptureManager {

    private var resultCode: Int = Activity.RESULT_CANCELED
    private var resultData: Intent? = null
    private var cachedProjection: MediaProjection? = null

    val hasPermission: Boolean
        get() = resultData != null && resultCode == Activity.RESULT_OK

    /** MainActivity, createScreenCaptureIntent() sonucunu (onActivityResult) burada saklar. */
    fun grantPermission(code: Int, data: Intent) {
        resultCode = code
        resultData = data
        cachedProjection = null
    }

    fun revokePermission() {
        cachedProjection?.stop()
        cachedProjection = null
        resultCode = Activity.RESULT_CANCELED
        resultData = null
    }

    fun createScreenCaptureIntent(context: Context): Intent {
        val manager =
            context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        return manager.createScreenCaptureIntent()
    }

    /**
     * Tek bir ekran görüntüsü yakalar ve base64 JPEG (data-url'siz, ham base64)
     * olarak döner. Bloklayan (senkron) bir çağrıdır — ActionRouter'daki diğer
     * ağ tabanlı action'larla (WeatherActions vb.) aynı senkron desene uyar.
     * SADECE bir foreground service (mediaProjection tipi) çalışırken çağır.
     */
    fun captureOnceBlocking(context: Context, timeoutMs: Long = 4000): String? {
        val projection = getOrCreateProjection(context) ?: return null

        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi

        val thread = HandlerThread("JarvisScreenCapture").apply { start() }
        val handler = Handler(thread.looper)
        val latch = CountDownLatch(1)
        var base64Result: String? = null

        val imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage()
            if (image != null) {
                try {
                    base64Result = imageToBase64Jpeg(image, width, height)
                } finally {
                    image.close()
                    latch.countDown()
                }
            }
        }, handler)

        val virtualDisplay = projection.createVirtualDisplay(
            "JarvisScreenCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader.surface, null, handler
        )

        latch.await(timeoutMs, TimeUnit.MILLISECONDS)

        virtualDisplay?.release()
        imageReader.close()
        thread.quitSafely()
        // Projeksiyonu (cachedProjection) burada DURDURMUYORUZ — kullanıcı tekrar
        // "ekranı analiz et" derse yeniden izin sormamak için canlı tutuyoruz.

        return base64Result
    }

    private fun getOrCreateProjection(context: Context): MediaProjection? {
        cachedProjection?.let { return it }
        val data = resultData ?: return null
        val manager =
            context.applicationContext.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection = manager.getMediaProjection(resultCode, data) ?: return null
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                cachedProjection = null
            }
        }, Handler(Looper.getMainLooper()))
        cachedProjection = projection
        return projection
    }

    private fun imageToBase64Jpeg(image: Image, width: Int, height: Int): String {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width

        val rawBitmap = Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
        )
        rawBitmap.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(rawBitmap, 0, 0, width, height)

        val stream = ByteArrayOutputStream()
        cropped.compress(Bitmap.CompressFormat.JPEG, 70, stream)
        rawBitmap.recycle()
        cropped.recycle()
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }
}
