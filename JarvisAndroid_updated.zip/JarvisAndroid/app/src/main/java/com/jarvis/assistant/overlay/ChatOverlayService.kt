package com.jarvis.assistant.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.Config
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Diğer uygulamaların (oyunlar dahil) üzerinde, ekranın sağ kenarından taşan
 * küçük bir "çıkıntı" (Game Turbo'daki kenar sekmesi gibi) gösterir.
 * - Kısa dokunuş: direkt sesli dinlemeye geçer, cevabı hem sesli okur hem de
 *   birkaç saniyeliğine küçük bir balonda gösterir. Hiçbir uygulamaya geçiş yapmaz.
 * - Basılı tutma: yazarak sohbet edebileceğin yüzen paneli açar.
 * - Sürükleme: sekmeyi kenar boyunca yukarı/aşağı taşır.
 */
class ChatOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var handleView: View? = null
    private var panelView: View? = null
    private var handleParams: WindowManager.LayoutParams? = null
    private var savedPortraitHandleY: Int? = null

    private lateinit var localLlm: LocalLlmClient
    private lateinit var speechManager: SpeechManager
    private val messages = mutableListOf<ChatMessage>()
    private var adapter: ChatAdapter? = null

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private val systemPrompt =
        "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    private val configPrefs by lazy {
        getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)
    }
    private val prefsListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == "overlay_handle_height_dp" || key == "overlay_handle_width_dp" || key == "overlay_handle_side_right") {
            applyHandleGeometry()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        localLlm = LocalLlmClient(this)
        speechManager = SpeechManager(this)
        startForegroundWithNotification()
        configPrefs.registerOnSharedPreferenceChangeListener(prefsListener)
        try {
            addHandleView()
        } catch (t: Throwable) {
            Log.e("ChatOverlayService", "Çıkıntı eklenemedi", t)
            Toast.makeText(this, "Çıkıntı eklenemedi: ${t.message}", Toast.LENGTH_LONG).show()
            isRunning = false
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_APPLY_GEOMETRY) {
            applyHandleGeometry()
        }
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val params = handleParams ?: return
        val view = handleView ?: return
        val metrics = resources.displayMetrics
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            // Fullscreen video (YouTube etc.) is almost always landscape.
            // Remember the portrait spot, then tuck the tab into the top
            // corner so it stops sitting over the video's own controls.
            if (savedPortraitHandleY == null) savedPortraitHandleY = params.y
            params.y = (16 * metrics.density).toInt()
        } else {
            params.y = savedPortraitHandleY ?: (metrics.heightPixels / 3)
            savedPortraitHandleY = null
        }
        applyHandleGeometry()
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    override fun onDestroy() {
        isRunning = false
        configPrefs.unregisterOnSharedPreferenceChangeListener(prefsListener)
        removePanelView()
        removeReplyBubble()
        removeHandleView()
        if (::speechManager.isInitialized) speechManager.destroy()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------
    // Foreground notification (required to keep drawing over other apps)
    // ---------------------------------------------------------------------

    private fun startForegroundWithNotification() {
        val channelId = "jarvis_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.overlay_notification_channel),
                NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this, 1001, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1001, notification)
        }
    }

    // ---------------------------------------------------------------------
    // Collapsed edge "tab" — half hangs off the right edge of the screen
    // ---------------------------------------------------------------------

    private fun addHandleView() {
        if (handleView != null) return

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_handle, null)

        val metrics = resources.displayMetrics
        val screenWidth = metrics.widthPixels
        val config = Config(this)
        val handleWidthPx = (config.handleWidthDp * metrics.density).toInt()
        val handleHeightPx = (config.handleHeightDp * metrics.density).toInt()
        view.layoutParams = ViewGroup.LayoutParams(handleWidthPx, handleHeightPx)

        val params = WindowManager.LayoutParams(
            handleWidthPx,
            handleHeightPx,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Only ~half of the tab stays visible — the rest pokes off-screen,
            // giving the "çıkıntı" (protrusion) look instead of a floating icon.
            x = if (config.handleOnRightSide) screenWidth - handleWidthPx / 2 else -handleWidthPx / 2
            y = metrics.heightPixels / 3
        }
        handleParams = params

        var downRawY = 0f
        var downParamY = 0
        var isDragging = false
        var downTime = 0L

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawY = event.rawY
                    downParamY = params.y
                    isDragging = false
                    downTime = System.currentTimeMillis()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - downRawY
                    if (abs(dy) > 12) isDragging = true
                    if (isDragging) {
                        params.y = (downParamY + dy).toInt()
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        val heldMs = System.currentTimeMillis() - downTime
                        if (heldMs >= LONG_PRESS_MS) togglePanel() else toggleQuickVoice()
                    }
                    true
                }
                else -> false
            }
        }

        handleView = view
        windowManager.addView(view, params)

        // Some OEM skins (MIUI included) will recalculate/override overlay window
        // bounds when the app underneath goes fullscreen/immersive (e.g. video
        // playback), silently stretching WRAP_CONTENT-like windows. Watch every
        // layout pass and snap the size back if it ever drifts from what we set.
        view.viewTreeObserver.addOnGlobalLayoutListener {
            val cfg = Config(this)
            val expectedW = (cfg.handleWidthDp * metrics.density).toInt()
            val expectedH = (cfg.handleHeightDp * metrics.density).toInt()
            val drifted = params.width != expectedW || params.height != expectedH ||
                view.width != expectedW || view.height != expectedH
            if (drifted) {
                params.width = expectedW
                params.height = expectedH
                params.x = if (cfg.handleOnRightSide) {
                    metrics.widthPixels - expectedW / 2
                } else {
                    -expectedW / 2
                }
                view.layoutParams = ViewGroup.LayoutParams(expectedW, expectedH)
                runCatching { windowManager.updateViewLayout(view, params) }
            }
        }
    }

    private fun removeHandleView() {
        handleView?.let {
            runCatching { windowManager.removeView(it) }
        }
        handleView = null
    }

    /** Boy/kalınlık/taraf ayarı değiştiğinde, çıkıntı zaten ekrandaysa anında yeniden uygular. */
    private fun applyHandleGeometry() {
        val view = handleView ?: return
        val params = handleParams ?: return
        val metrics = resources.displayMetrics
        val config = Config(this)
        val widthPx = (config.handleWidthDp * metrics.density).toInt()
        val heightPx = (config.handleHeightDp * metrics.density).toInt()

        view.layoutParams = ViewGroup.LayoutParams(widthPx, heightPx)
        params.width = widthPx
        params.height = heightPx
        params.x = if (config.handleOnRightSide) metrics.widthPixels - widthPx / 2 else -widthPx / 2
        runCatching { windowManager.updateViewLayout(view, params) }
    }

    // ---------------------------------------------------------------------
    // Quick voice tap — press the tab, talk, get a spoken + short-lived
    // text reply, all without opening the panel or switching apps.
    // ---------------------------------------------------------------------

    private var isListening = false

    private fun toggleQuickVoice() {
        if (isListening) {
            speechManager.stopListening()
            isListening = false
            setHandleState(HandleState.IDLE)
            return
        }
        isListening = true
        setHandleState(HandleState.LISTENING)
        speechManager.startListening(
            onResult = { text ->
                isListening = false
                setHandleState(HandleState.THINKING)
                handleQuickVoiceCommand(text)
            },
            onError = { err ->
                isListening = false
                setHandleState(HandleState.IDLE)
                showReplyBubble(err)
            }
        )
    }

    private fun handleQuickVoiceCommand(text: String) {
        val normalized = text.trim().lowercase()
        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            respondQuickVoice(localResult)
            return
        }
        if (!localLlm.isModelReady) {
            respondQuickVoice("Bunu anlayamadım. Ana uygulamadan yerel model seçebilirsin.")
            return
        }
        serviceScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            respondQuickVoice(reply)
        }
    }

    private fun respondQuickVoice(reply: String) {
        setHandleState(HandleState.SPEAKING)
        showReplyBubble(reply)
        speechManager.speak(reply)
        // No completion callback from SpeechManager.speak — fall back to idle
        // after a short delay so the tab doesn't stay lit up indefinitely.
        handleView?.postDelayed({ setHandleState(HandleState.IDLE) }, 3500)
    }

    private enum class HandleState { IDLE, LISTENING, THINKING, SPEAKING }

    private fun setHandleState(state: HandleState) {
        val bg = handleView?.findViewById<View>(R.id.handleBg) ?: return
        val color = when (state) {
            HandleState.IDLE -> ContextCompat.getColor(this, R.color.jarvis_accent)
            HandleState.LISTENING -> ContextCompat.getColor(this, R.color.jarvis_listening)
            HandleState.THINKING -> ContextCompat.getColor(this, R.color.jarvis_thinking)
            HandleState.SPEAKING -> ContextCompat.getColor(this, R.color.jarvis_speaking)
        }
        val drawable = bg.background?.mutate()
        if (drawable is android.graphics.drawable.GradientDrawable) {
            drawable.setColor(color)
        }
    }

    private var replyBubble: View? = null

    private fun showReplyBubble(text: String) {
        removeReplyBubble()

        val bubble = android.widget.TextView(this).apply {
            this.text = text
            setTextColor(ContextCompat.getColor(context, R.color.jarvis_text))
            setBackgroundResource(R.drawable.bg_bubble_jarvis)
            setPadding(24, 18, 24, 18)
            maxWidth = (240 * resources.displayMetrics.density).toInt()
            textSize = 14f
        }

        val onRight = Config(this).handleOnRightSide
        val handleX = handleParams?.x ?: resources.displayMetrics.widthPixels
        val handleWidthPx = handleView?.width ?: (6 * resources.displayMetrics.density).toInt()
        val bubbleWidthPx = (240 * resources.displayMetrics.density).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (onRight) {
                (handleX - bubbleWidthPx - (12 * resources.displayMetrics.density)).toInt().coerceAtLeast(0)
            } else {
                (handleX + handleWidthPx + (12 * resources.displayMetrics.density)).toInt()
            }
            y = handleParams?.y ?: 100
        }

        runCatching { windowManager.addView(bubble, params) }
        replyBubble = bubble

        bubble.postDelayed({ removeReplyBubble() }, 4200)
    }

    private fun removeReplyBubble() {
        replyBubble?.let { runCatching { windowManager.removeView(it) } }
        replyBubble = null
    }

    // ---------------------------------------------------------------------
    // Expanded floating chat panel (opened via long-press on the tab)
    // ---------------------------------------------------------------------

    private fun togglePanel() {
        if (panelView != null) {
            removePanelView()
        } else {
            addPanelView()
        }
    }

    private fun addPanelView() {
        removeReplyBubble()
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_panel, null)

        val onRight = Config(this).handleOnRightSide
        val handleWidthPx = handleView?.width ?: (6 * resources.displayMetrics.density).toInt()
        val panelWidthPx = 320 * resources.displayMetrics.density

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (onRight) {
                ((handleParams?.x ?: 0) - panelWidthPx).toInt().coerceAtLeast(0)
            } else {
                (handleParams?.x ?: 0) + handleWidthPx
            }
            y = handleParams?.y ?: 100
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        setupPanelContent(view)
        makeHeaderDraggable(view, params)

        panelView = view
        windowManager.addView(view, params)
        handleView?.visibility = View.GONE
    }

    private fun removePanelView() {
        panelView?.let {
            runCatching { windowManager.removeView(it) }
        }
        panelView = null
        handleView?.visibility = View.VISIBLE
    }

    private fun makeHeaderDraggable(panel: View, params: WindowManager.LayoutParams) {
        val header = panel.findViewById<View>(R.id.panelHeader)
        var downRawX = 0f
        var downRawY = 0f
        var downX = 0
        var downY = 0

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = params.x
                    downY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (downX + (event.rawX - downRawX)).toInt()
                    params.y = (downY + (event.rawY - downRawY)).toInt()
                    windowManager.updateViewLayout(panel, params)
                    true
                }
                else -> false
            }
        }

        panel.findViewById<ImageButton>(R.id.panelCollapse).setOnClickListener {
            removePanelView()
        }
    }

    private fun setupPanelContent(panel: View) {
        val recycler = panel.findViewById<RecyclerView>(R.id.chatRecycler)
        val input = panel.findViewById<EditText>(R.id.messageInput)
        val sendButton = panel.findViewById<ImageButton>(R.id.sendButton)
        val micButton = panel.findViewById<ImageButton>(R.id.micButton)

        if (adapter == null) {
            adapter = ChatAdapter(messages)
            if (messages.isEmpty()) {
                messages.add(ChatMessage("Merhaba! Buradan da yazabilirsin.", isUser = false))
            }
        }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text, recycler)
            }
        }

        micButton.setOnClickListener {
            speechManager.startListening(
                onResult = { text -> handleUserMessage(text, recycler) },
                onError = { err -> addMessage(err, isUser = false, recycler) }
            )
        }
    }

    private fun handleUserMessage(text: String, recycler: RecyclerView) {
        addMessage(text, isUser = true, recycler)

        val normalized = text.trim().lowercase()
        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            addMessage(localResult, isUser = false, recycler)
            speechManager.speak(localResult)
            return
        }

        if (!localLlm.isModelReady) {
            addMessage("Bunu anlayamadım. Ana uygulamadan yerel model seçebilirsin.", isUser = false, recycler)
            return
        }

        serviceScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            addMessage(reply, isUser = false, recycler)
            speechManager.speak(reply)
        }
    }

    private fun addMessage(text: String, isUser: Boolean, recycler: RecyclerView) {
        adapter?.addMessage(ChatMessage(text, isUser))
        recycler.scrollToPosition(messages.size - 1)
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

    companion object {
        private const val LONG_PRESS_MS = 420L
        private const val ACTION_APPLY_GEOMETRY = "com.jarvis.assistant.overlay.APPLY_GEOMETRY"

        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, ChatOverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ChatOverlayService::class.java))
        }

        /** Boy/kalınlık/taraf ayarı kaydedildiğinde çağrılır — servis çalışıyorsa anında uygular. */
        fun applyGeometry(context: Context) {
            if (!isRunning) return
            val intent = Intent(context, ChatOverlayService::class.java).apply {
                action = ACTION_APPLY_GEOMETRY
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }
}
