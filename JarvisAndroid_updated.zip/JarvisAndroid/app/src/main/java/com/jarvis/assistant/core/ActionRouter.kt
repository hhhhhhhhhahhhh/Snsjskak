package com.jarvis.assistant.core

import android.content.Context
import com.jarvis.assistant.actions.*
import com.jarvis.assistant.ai.GroqVisionClient
import com.jarvis.assistant.memory.MemoryManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

/**
 * Executes a single tool call requested by Gemini and returns a short,
 * human-readable result string that gets fed back into the model.
 *
 * This mirrors the "actions/" package from the desktop version. Two pieces
 * that were originally left out now have Android equivalents:
 *  - analyze_screen -> MediaProjection screen capture + Groq vision call
 *    (ScreenCaptureManager/ScreenCaptureService + GroqVisionClient)
 *  - get_youtube_stats -> YouTube Data API v3 (YouTubeStatsActions)
 *
 * Still intentionally NOT included, for reasons that are Android/product
 * limitations rather than missing effort:
 *  - shell_run (arbitrary terminal execution — Android's app sandbox has no
 *    general-purpose shell to expose without root, and wiring an LLM up to
 *    execute unconstrained commands from a misheard voice command is a real
 *    safety risk, not just a technical one)
 *  - Apple Music / iPhone Health / Apple Calendar integrations (macOS/iOS-only,
 *    no Android equivalent exists to port)
 */
class ActionRouter(private val context: Context, private val memory: MemoryManager) {

    fun execute(name: String, args: JSONObject): String {
        return try {
            when (name) {
                "open_app" -> AppLauncher.open(context, args.getString("app_name"))

                "sys_info" -> SystemInfoActions.query(context, args.optString("kind", "all"))

                "get_weather" -> WeatherActions.getWeather(args.optString("location", "Istanbul"))

                "browser_control" -> when (args.getString("action")) {
                    "open_url" -> BrowserActions.openUrl(context, args.getString("query"))
                    "search" -> BrowserActions.search(context, args.getString("query"))
                    "play_youtube" -> BrowserActions.playYoutube(context, args.getString("query"))
                    else -> "Bilinmeyen tarayıcı işlemi."
                }

                "play_media" -> MediaActions.play(
                    context,
                    args.getString("query"),
                    args.optString("provider", "youtube")
                )

                "send_whatsapp_message" -> WhatsAppActions.sendMessage(
                    context,
                    args.getString("recipient"),
                    args.getString("message")
                )

                "save_whatsapp_contact" -> {
                    WhatsAppActions.saveContact(context, args.getString("name"), args.getString("phone"))
                    "${args.getString("name")} kaydedildi."
                }

                "save_memory" -> {
                    memory.save(args.getString("key"), args.getString("value"))
                    "Not edildi."
                }

                "delete_memory" -> {
                    val ok = memory.delete(args.getString("key"))
                    if (ok) "Silindi." else "Bu bilgi hafızada bulunamadı."
                }

                "get_calendar_events" -> {
                    val range = resolveRange(args.optString("query", "today"))
                    CalendarActions.listEvents(context, range.first, range.second)
                }

                "add_calendar_event" -> CalendarActions.addEvent(
                    context,
                    args.getString("title"),
                    args.getString("start_iso"),
                    args.optString("end_iso", null)
                )

                "delete_calendar_event" -> CalendarActions.deleteEvent(context, args.getString("title"))

                "add_reminder" -> CalendarActions.addReminder(
                    context,
                    args.getString("title"),
                    args.getString("due_iso")
                )

                "get_reminders" -> {
                    val range = resolveRange(args.optString("query", "upcoming"))
                    CalendarActions.listEvents(context, range.first, range.second)
                }

                "analyze_screen" -> {
                    if (!ScreenCaptureManager.hasPermission) {
                        "Ekran analizi için önce izin vermen gerekiyor. Ana ekrandaki " +
                            "\"Ekranı Analiz Et\" düğmesine dokunup ekran kaydı iznini ver, " +
                            "sonra tekrar dene."
                    } else {
                        val apiKey = Config(context).apiKey
                        if (apiKey.isNullOrBlank()) {
                            "Groq API anahtarı ayarlanmamış, önce onu ekle."
                        } else {
                            val base64 = ScreenCaptureResultHolder.awaitNext(context)
                            if (base64 == null) {
                                "Ekran görüntüsü alınamadı, tekrar dener misin?"
                            } else {
                                GroqVisionClient.analyzeImage(
                                    apiKey,
                                    base64,
                                    args.optString("question", "Bu ekranda ne görüyorsun? Kısaca özetle.")
                                )
                            }
                        }
                    }
                }

                "get_youtube_stats" -> YouTubeStatsActions.getChannelStats(
                    Config(context).youtubeApiKey,
                    args.getString("channel")
                )

                else -> "Bilinmeyen komut: $name"
            }
        } catch (e: Exception) {
            "İşlem sırasında hata oluştu: ${e.message}"
        }
    }

    /** Turns loose expressions like "today"/"tomorrow"/"this week" into a millis range. */
    private fun resolveRange(query: String): Pair<Long, Long> {
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        return when {
            query.contains("tomorrow") || query.contains("yarın") -> {
                cal.add(Calendar.DAY_OF_YEAR, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
                val start = cal.timeInMillis
                cal.add(Calendar.DAY_OF_YEAR, 1)
                Pair(start, cal.timeInMillis)
            }
            query.contains("week") || query.contains("hafta") -> {
                Pair(now, now + 7L * 24 * 60 * 60 * 1000)
            }
            query.contains("month") || query.contains("ay") -> {
                Pair(now, now + 30L * 24 * 60 * 60 * 1000)
            }
            query.contains("upcoming") || query.contains("yaklaşan") -> {
                Pair(now, now + 14L * 24 * 60 * 60 * 1000)
            }
            else -> { // today
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
                val start = cal.timeInMillis
                cal.add(Calendar.DAY_OF_YEAR, 1)
                Pair(start, cal.timeInMillis)
            }
        }
    }
}
