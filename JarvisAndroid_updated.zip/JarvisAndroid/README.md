# J.A.R.V.I.S — Android Sürümü (API'siz)

Bu sürüm **hiçbir yapay zeka API'sine bağlanmaz**. Serbest sohbet/soru-cevap
özelliği yoktur; sadece önceden tanımlı sabit komutları anlar. API kotası,
faturalandırma veya internet bağlantı sorunu olmadan çalışır (uygulama
açma, hava durumu araması ve WhatsApp/medya işlemleri internet gerektirse
de, bunlar için üçüncü parti bir yapay zeka servisine ihtiyaç yoktur).

## Anlayabildiği örnek komutlar

- "Spotify aç", "Google aç" — yüklü bir uygulamayı açar
- "İstanbul'da hava durumu" — Google'da hava durumu araması yapar
- "pil durumu", "ram durumu", "depolama durumu", "saat kaç"
- "Ali'ye whatsapp'tan merhaba yaz" — WhatsApp'ta mesaj taslağı hazırlar (rehberden numara bulur)
- "böyle bir şarkı çal" — YouTube/Spotify'da arar
- "14:30'da toplantı hatırlat" — takvime hatırlatıcı ekler
- "sesi değiştir" — TTS sesini değiştirir

Bunların dışındaki her şeye "Bunu anlayamadım" der ve örnek komutları gösterir.

## Kurulum (Android Studio)

1. **Android Studio**'yu aç (yoksa https://developer.android.com/studio adresinden indir).
2. `File → Open` ile bu `JarvisAndroid` klasörünü seç.
3. Gradle senkronizasyonu bitene kadar bekle (ilk açılışta internet ister, bağımlılıkları indirir).
4. Telefonunu USB ile bağla (Geliştirici Seçenekleri → USB Hata Ayıklama açık) veya bir emülatör oluştur.
5. Üstteki ▶️ (Run) butonuna bas.
6. Uygulama ilk açıldığında senden Groq API anahtarı ister:
   - https://console.groq.com → API Keys → yeni anahtar oluştur (kredi kartı istemez)
   - Anahtarı kopyala, uygulamaya yapıştır, kaydet.
   - Groq'un ücretsiz katmanı Gemini'den çok daha yüksek günlük limitli ve xAI gibi ödeme bilgisi istemez.

Derlemek için internet ve JDK 17 gerekir (Android Studio bunu genelde otomatik indirir).

## Neler Aynı Şekilde Çalışıyor

| Özellik | Nasıl |
|---|---|
| Sesli/yazılı AI sohbet (Groq/GPT-OSS 120B) | `GroqClient` — OpenAI-uyumlu function calling API'si ile masaüstündeki `main.py` mantığının aynısı. (Not: Groq, `llama-3.3-70b-versatile`'ı 17 Haziran 2026'da kullanımdan kaldırdı; bu proje `openai/gpt-oss-120b`'a güncellendi.) |
| Uygulama açma | `AppLauncher` — yüklü uygulamalar arasında isimle arar, `PackageManager` ile açar |
| Hava durumu | `WeatherActions` — Open-Meteo (ücretsiz, API anahtarı gerekmez) |
| Sistem bilgisi (pil, RAM, depolama, saat) | `SystemInfoActions` — `BatteryManager`/`ActivityManager`/`StatFs` |
| Tarayıcı arama / URL açma | `BrowserActions` — `Intent.ACTION_VIEW` |
| YouTube / Spotify oynatma | `MediaActions` — uygulama varsa direkt açar, yoksa tarayıcıya düşer |
| WhatsApp mesajı | `WhatsAppActions` — `wa.me` linkiyle mesaj hazırlar (Android'de 3. parti uygulamalar mesajı **otomatik gönderemez**, kullanıcı dokunup göndermeli — bu bir Android/WhatsApp kısıtı) |
| Takvim & Hatırlatıcı | `CalendarActions` — Android Takvim sağlayıcısı (`CalendarContract`); hatırlatıcılar ⏰ önekiyle aynı takvime yazılır |
| Bellek (hatırlama) | `MemoryManager` — cihaz içinde JSON dosyası olarak saklanır |
| Sesli komut / TTS | `SpeechManager` — Android'in yerleşik `SpeechRecognizer` ve `TextToSpeech` API'leri |

## Sonradan Eklenen Özellikler

- **Ekran analizi (`analyze_screen`)** — `ScreenCaptureManager` +
  `ScreenCaptureService` ile `MediaProjection` üzerinden tek kare ekran
  görüntüsü yakalar, `GroqVisionClient` ile Groq'un multimodal modeline
  (`qwen/qwen3.6-27b`) gönderir. Ana ekrandaki kamera ikonuyla kullanıcıdan
  BİR KEZ ekran kaydı izni istenir; süreç canlı kaldığı sürece tekrar
  sorulmaz. Android 14+'ta `mediaProjection` tipinde bir foreground service
  çalışması zorunlu olduğu için yakalama işlemi kısa ömürlü bir servis
  içinden yapılır.
- **YouTube kanal istatistikleri (`get_youtube_stats`)** — `YouTubeStatsActions`,
  YouTube Data API v3 üzerinden abone/görüntülenme/video sayısı getirir.
  Ayrı ve ücretsiz bir API anahtarı gerekir (Google Cloud Console →
  "YouTube Data API v3" → Kimlik Bilgileri), ayarlara eklenebilir.

## Bilerek Çıkarılmaya Devam Eden Özellikler

Bunlar Android'in güvenlik/izin modeliyle temelden uyuşmadığı için hâlâ
**dahil edilmedi**:

- **Terminal komutu çalıştırma (`shell_run`)** — Android uygulamaları
  sandbox içinde çalışır, root olmadan genel amaçlı bir shell'e erişim
  vermez. Ayrıca bir sesli komutun yanlış anlaşılması ihtimaliyle bir AI
  modeline sınırsız komut çalıştırma yetkisi vermek başlı başına bir risktir
  — bu yalnızca teknik değil, güvenlik açısından da bilinçli bir tercihtir.
- **Apple Takvim/Hatırlatıcılar/Music, iPhone Sağlık verisi** — bunlar zaten
  yalnızca macOS/iOS'a özeldi; Android'de karşılığı yok (en yakın eşdeğeri
  olan Android Takvim zaten kullanılıyor).

## Klasör Yapısı

```
app/src/main/java/com/jarvis/assistant/
  ai/            Gemini istemcisi ve araç (tool) tanımları
  actions/       Her özelliğin Android karşılığı (open_app, weather, whatsapp, ...)
  core/          Sohbet UI mantığı, komut yönlendirme, ayarlar
  memory/        Kalıcı hafıza (JSON tabanlı)
  voice/         Sesli komut + sesli yanıt
  ui/            API anahtarı kurulum ekranı
```

## Notlar

- `minSdk = 26` (Android 8.0+) — güncel telefonların büyük çoğunluğunu kapsar.
- İlk çalıştırmada mikrofon, takvim ve rehber izinleri istenir.
- WhatsApp, Spotify, YouTube gibi uygulamalar telefonda yüklü değilse otomatik
  olarak tarayıcı sürümüne yönlendirilir.
