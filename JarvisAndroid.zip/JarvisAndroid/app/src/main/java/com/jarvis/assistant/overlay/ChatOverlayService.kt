package com.jarvis.assistant.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.ImageButton
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlin.math.abs

/**
 * Diğer uygulamaların (oyunlar dahil) üzerinde, ekranın sağ kenarından taşan
 * bir "çıkıntı" (Game Turbo'daki kenar sekmesi gibi) gösterir. Bu sekme
 * yukarı/aşağı sürüklenebilir; dokununca JARVIS'in yüzen sohbet paneli açılır.
 */
class ChatOverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var handleView: View? = null
    private var panelView: View? = null
    private var handleParams: WindowManager.LayoutParams? = null

    private lateinit var localLlm: LocalLlmClient
    private lateinit var speechManager: SpeechManager
    private val messages = mutableListOf<ChatMessage>()
    private var adapter: ChatAdapter? = null

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private val systemPrompt =
        "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        localLlm = LocalLlmClient(this)
        speechManager = SpeechManager(this)
        startForegroundWithNotification()
        addHandleView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        removePanelView()
        removeHandleView()
        if (::speechManager.isInitialized) speechManager.destroy()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------
    // Foreground notification (required to keep drawing over other apps)
    // ---------------------------------------------------------------------

    private fun startForegroundWithNotification() {
        val channelId = "jarvis_overlay_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.overlay_notification_channel),
                NotificationManager.IMPORTANCE_MIN
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(getString(R.string.overlay_notification_title))
            .setContentText(getString(R.string.overlay_notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openAppIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceCompat.startForeground(
                this, 1001, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(1001, notification)
        }
    }

    // ---------------------------------------------------------------------
    // Collapsed edge "tab" — half hangs off the right edge of the screen
    // ---------------------------------------------------------------------

    private fun addHandleView() {
        if (handleView != null) return

        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_handle, null)

        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        val screenWidth = metrics.widthPixels
        val handleWidthPx = (60 * metrics.density).toInt()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            // Only ~half of the tab stays visible — the rest pokes off-screen,
            // giving the "çıkıntı" (protrusion) look instead of a floating icon.
            x = screenWidth - handleWidthPx / 2
            y = metrics.heightPixels / 3
        }
        handleParams = params

        var downRawY = 0f
        var downParamY = 0
        var isDragging = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawY = event.rawY
                    downParamY = params.y
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = event.rawY - downRawY
                    if (abs(dy) > 12) isDragging = true
                    if (isDragging) {
                        params.y = (downParamY + dy).toInt()
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) togglePanel()
                    true
                }
                else -> false
            }
        }

        handleView = view
        windowManager.addView(view, params)
    }

    private fun removeHandleView() {
        handleView?.let {
            runCatching { windowManager.removeView(it) }
        }
        handleView = null
    }

    // ---------------------------------------------------------------------
    // Expanded floating chat panel
    // ---------------------------------------------------------------------

    private fun togglePanel() {
        if (panelView != null) {
            removePanelView()
        } else {
            addPanelView()
        }
    }

    private fun addPanelView() {
        val inflater = LayoutInflater.from(this)
        val view = inflater.inflate(R.layout.overlay_panel, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayWindowType(),
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ((handleParams?.x ?: 0) - 320 * resources.displayMetrics.density).toInt().coerceAtLeast(0)
            y = handleParams?.y ?: 100
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        setupPanelContent(view)
        makeHeaderDraggable(view, params)

        panelView = view
        windowManager.addView(view, params)
        handleView?.visibility = View.GONE
    }

    private fun removePanelView() {
        panelView?.let {
            runCatching { windowManager.removeView(it) }
        }
        panelView = null
        handleView?.visibility = View.VISIBLE
    }

    private fun makeHeaderDraggable(panel: View, params: WindowManager.LayoutParams) {
        val header = panel.findViewById<View>(R.id.panelHeader)
        var downRawX = 0f
        var downRawY = 0f
        var downX = 0
        var downY = 0

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    downX = params.x
                    downY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (downX + (event.rawX - downRawX)).toInt()
                    params.y = (downY + (event.rawY - downRawY)).toInt()
                    windowManager.updateViewLayout(panel, params)
                    true
                }
                else -> false
            }
        }

        panel.findViewById<ImageButton>(R.id.panelCollapse).setOnClickListener {
            removePanelView()
        }
    }

    private fun setupPanelContent(panel: View) {
        val recycler = panel.findViewById<RecyclerView>(R.id.chatRecycler)
        val input = panel.findViewById<EditText>(R.id.messageInput)
        val sendButton = panel.findViewById<ImageButton>(R.id.sendButton)
        val micButton = panel.findViewById<ImageButton>(R.id.micButton)

        if (adapter == null) {
            adapter = ChatAdapter(messages)
            if (messages.isEmpty()) {
                messages.add(ChatMessage("Merhaba! Buradan da yazabilirsin.", isUser = false))
            }
        }
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text, recycler)
            }
        }

        micButton.setOnClickListener {
            speechManager.startListening(
                onResult = { text -> handleUserMessage(text, recycler) },
                onError = { err -> addMessage(err, isUser = false, recycler) }
            )
        }
    }

    private fun handleUserMessage(text: String, recycler: RecyclerView) {
        addMessage(text, isUser = true, recycler)

        val normalized = text.trim().lowercase()
        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            addMessage(localResult, isUser = false, recycler)
            speechManager.speak(localResult)
            return
        }

        if (!localLlm.isModelReady) {
            addMessage("Bunu anlayamadım. Ana uygulamadan yerel model seçebilirsin.", isUser = false, recycler)
            return
        }

        serviceScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            addMessage(reply, isUser = false, recycler)
            speechManager.speak(reply)
        }
    }

    private fun addMessage(text: String, isUser: Boolean, recycler: RecyclerView) {
        adapter?.addMessage(ChatMessage(text, isUser))
        recycler.scrollToPosition(messages.size - 1)
    }

    private fun overlayWindowType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

    companion object {
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, ChatOverlayService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ChatOverlayService::class.java))
        }
    }
}
