package com.jarvis.assistant.core

import android.content.Context
import android.content.SharedPreferences

/** Stores the Groq API key and small persistent settings on-device. */
class Config(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("jarvis_config", Context.MODE_PRIVATE)

    var apiKey: String?
        get() = prefs.getString(KEY_API, null)
        set(value) = prefs.edit().putString(KEY_API, value).apply()

    var weatherDefaultCity: String?
        get() = prefs.getString(KEY_CITY, "Istanbul")
        set(value) = prefs.edit().putString(KEY_CITY, value).apply()

    /** Kenar çıkıntısının boyu (dp - uzunluk). */
    var handleHeightDp: Int
        get() = prefs.getInt(KEY_HANDLE_HEIGHT, DEFAULT_HANDLE_HEIGHT_DP)
        set(value) = prefs.edit().putInt(KEY_HANDLE_HEIGHT, value.coerceIn(MIN_HANDLE_HEIGHT_DP, MAX_HANDLE_HEIGHT_DP)).apply()

    /** Kenar çıkıntısının kalınlığı (dp - genişlik). */
    var handleWidthDp: Int
        get() = prefs.getInt(KEY_HANDLE_WIDTH, DEFAULT_HANDLE_WIDTH_DP)
        set(value) = prefs.edit().putInt(KEY_HANDLE_WIDTH, value.coerceIn(MIN_HANDLE_WIDTH_DP, MAX_HANDLE_WIDTH_DP)).apply()

    /** true = ekranın sağ kenarında, false = sol kenarında. */
    var handleOnRightSide: Boolean
        get() = prefs.getBoolean(KEY_HANDLE_SIDE, true)
        set(value) = prefs.edit().putBoolean(KEY_HANDLE_SIDE, value).apply()

    val hasApiKey: Boolean
        get() = !apiKey.isNullOrBlank()

    companion object {
        private const val KEY_API = "xai_api_key"
        private const val KEY_CITY = "default_city"
        private const val KEY_HANDLE_HEIGHT = "overlay_handle_height_dp"
        private const val KEY_HANDLE_WIDTH = "overlay_handle_width_dp"
        private const val KEY_HANDLE_SIDE = "overlay_handle_side_right"

        const val DEFAULT_HANDLE_HEIGHT_DP = 14
        const val MIN_HANDLE_HEIGHT_DP = 10
        const val MAX_HANDLE_HEIGHT_DP = 120

        const val DEFAULT_HANDLE_WIDTH_DP = 6
        const val MIN_HANDLE_WIDTH_DP = 4
        const val MAX_HANDLE_WIDTH_DP = 30
    }
}
