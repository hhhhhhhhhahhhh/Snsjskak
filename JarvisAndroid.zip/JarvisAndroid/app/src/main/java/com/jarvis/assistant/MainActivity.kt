package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.ui.OrbView
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.launch

/**
 * JARVIS — sade sürüm: mikrofon butonuna basınca dinler (push-to-talk),
 * sabit komutları (uygulama aç, hava durumu, whatsapp, vb.) offline çalıştırır,
 * bunlara uymayan her şeyi telefonda çalışan yerel AI modeline (LiteRT-LM/Gemma) sorar.
 * Sürekli dinleme, uyandırma kelimesi ve arka plan servisi YOK — kasıtlı olarak sade.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var speechManager: SpeechManager
    private lateinit var adapter: ChatAdapter
    private lateinit var localLlm: LocalLlmClient
    private lateinit var orbView: OrbView

    private val messages = mutableListOf<ChatMessage>()
    private val permissionRequestCode = 42

    private val systemPrompt =
        "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    private val helpText = """
        Şunları deneyebilirsin:
        • "Spotify aç", "Google aç"
        • "İstanbul'da hava durumu"
        • "pil durumu", "ram durumu", "depolama durumu", "saat kaç"
        • "Ali'ye whatsapp'tan merhaba yaz"
        • "böyle bir şarkı çal"
        • "14:30'da toplantı hatırlat"
        • "sesi değiştir"
        Bunların dışındaki her şeyi telefonda çalışan yerel AI modeline soracağım.
    """.trimIndent()

    private val modelPickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        addMessage("Model dosyası kopyalanıyor, biraz sürebilir...", isUser = false)
        lifecycleScope.launch {
            val ok = localLlm.importModel(uri)
            addMessage(
                if (ok) "Yerel model hazır! Artık sabit komutlara uymayan her şeyi offline yanıtlayabilirim."
                else "Model dosyası okunamadı. Doğru .litertlm dosyasını seçtiğinden emin ol.",
                isUser = false
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        requestRuntimePermissions()

        speechManager = SpeechManager(this)
        localLlm = LocalLlmClient(this)

        orbView = findViewById(R.id.orbView)
        orbView.setState(OrbView.State.IDLE)

        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        val micButton = findViewById<ImageButton>(R.id.micButton)
        val voiceChangeButton = findViewById<ImageButton>(R.id.voiceChangeButton)
        val selectModelButton = findViewById<ImageButton>(R.id.selectModelButton)

        addMessage("Merhaba! Ben JARVIS. $helpText", isUser = false)
        if (!localLlm.isModelReady) {
            addMessage(
                "Serbest sohbet için bir yerel AI modeli seçmen gerekiyor. Yukarıdaki yükleme " +
                    "ikonuna dokunup, tarayıcından indirdiğin .litertlm model dosyasını seç.",
                isUser = false
            )
        }

        selectModelButton.setOnClickListener {
            modelPickerLauncher.launch(arrayOf("*/*"))
        }

        voiceChangeButton.setOnClickListener {
            addMessage(speechManager.cycleVoice(), isUser = false)
        }

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text)
            }
        }

        micButton.setOnClickListener { startVoiceInput() }
    }

    private fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun startVoiceInput() {
        if (!hasRecordAudioPermission()) {
            requestRuntimePermissions()
            return
        }
        orbView.setState(OrbView.State.LISTENING)
        speechManager.startListening(
            onResult = { text -> handleUserMessage(text) },
            onError = { err ->
                orbView.setState(OrbView.State.ERROR)
                addMessage(err, isUser = false)
                orbView.setState(OrbView.State.IDLE)
            }
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun handleUserMessage(text: String) {
        addMessage(text, isUser = true)
        orbView.setState(OrbView.State.THINKING)

        val normalized = text.trim().lowercase()
        if (normalized.contains("sesi değiştir") || normalized.contains("sesini değiştir") ||
            normalized.contains("ses değiştir")
        ) {
            val reply = speechManager.cycleVoice()
            addMessage(reply, isUser = false)
            orbView.setState(OrbView.State.IDLE)
            return
        }

        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            addMessage(localResult, isUser = false)
            orbView.setState(OrbView.State.SPEAKING)
            speechManager.speak(localResult)
            orbView.setState(OrbView.State.IDLE)
            return
        }

        if (!localLlm.isModelReady) {
            val msg = "Bunu anlayamadım ve henüz yerel model seçilmedi. $helpText"
            addMessage(msg, isUser = false)
            orbView.setState(OrbView.State.IDLE)
            speechManager.speak("Bunu anlayamadım.")
            return
        }

        lifecycleScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            addMessage(reply, isUser = false)
            orbView.setState(OrbView.State.SPEAKING)
            speechManager.speak(reply)
            orbView.setState(OrbView.State.IDLE)
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.size - 1)
    }

    private fun requestRuntimePermissions() {
        val needed = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS
        ).filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequestCode)
        }
    }

    override fun onDestroy() {
        if (::speechManager.isInitialized) {
            speechManager.destroy()
        }
        super.onDestroy()
    }
}
