package com.jarvis.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.EditText
import android.widget.ImageButton
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.jarvis.assistant.ai.LocalLlmClient
import com.jarvis.assistant.core.ChatAdapter
import com.jarvis.assistant.core.ChatMessage
import com.jarvis.assistant.core.Config
import com.jarvis.assistant.core.LocalCommandParser
import com.jarvis.assistant.overlay.ChatOverlayService
import com.jarvis.assistant.ui.OrbView
import com.jarvis.assistant.voice.SpeechManager
import kotlinx.coroutines.launch

/**
 * JARVIS — sade sürüm: mikrofon butonuna basınca dinler (push-to-talk),
 * sabit komutları (uygulama aç, hava durumu, whatsapp, vb.) offline çalıştırır,
 * bunlara uymayan her şeyi telefonda çalışan yerel AI modeline (LiteRT-LM/Gemma) sorar.
 * Sürekli dinleme, uyandırma kelimesi ve arka plan servisi YOK — kasıtlı olarak sade.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var speechManager: SpeechManager
    private lateinit var adapter: ChatAdapter
    private lateinit var localLlm: LocalLlmClient
    private lateinit var orbView: OrbView

    private val messages = mutableListOf<ChatMessage>()
    private val permissionRequestCode = 42

    private val systemPrompt =
        "Sen JARVIS'sin, telefonda çalışan kısa ve yardımsever bir Türkçe asistansın. Kısa ve net cevaplar ver."

    private val helpText = """
        Şunları deneyebilirsin:
        • "Spotify aç", "Google aç"
        • "İstanbul'da hava durumu"
        • "pil durumu", "ram durumu", "depolama durumu", "saat kaç"
        • "Ali'ye whatsapp'tan merhaba yaz"
        • "böyle bir şarkı çal"
        • "14:30'da toplantı hatırlat"
        • "sesi değiştir"
        Bunların dışındaki her şeyi telefonda çalışan yerel AI modeline soracağım.
    """.trimIndent()

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                ChatOverlayService.start(this)
                addMessage("Kenar çıkıntısı açıldı. Ekranın sağ kenarına bak. Boyunu değiştirmek için bu butona basılı tut.", isUser = false)
            } else {
                addMessage("İzin verilmedi, çıkıntı açılamadı.", isUser = false)
            }
        }

    private val modelPickerLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@registerForActivityResult
        addMessage("Model dosyası kopyalanıyor, biraz sürebilir...", isUser = false)
        lifecycleScope.launch {
            val ok = localLlm.importModel(uri)
            addMessage(
                if (ok) "Yerel model hazır! Artık sabit komutlara uymayan her şeyi offline yanıtlayabilirim."
                else "Model dosyası okunamadı. Doğru .litertlm dosyasını seçtiğinden emin ol.",
                isUser = false
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        requestRuntimePermissions()

        speechManager = SpeechManager(this)
        localLlm = LocalLlmClient(this)

        orbView = findViewById(R.id.orbView)
        orbView.setState(OrbView.State.IDLE)

        val recycler = findViewById<RecyclerView>(R.id.chatRecycler)
        adapter = ChatAdapter(messages)
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = adapter

        val input = findViewById<EditText>(R.id.messageInput)
        val sendButton = findViewById<ImageButton>(R.id.sendButton)
        val micButton = findViewById<ImageButton>(R.id.micButton)
        val voiceChangeButton = findViewById<ImageButton>(R.id.voiceChangeButton)
        val selectModelButton = findViewById<ImageButton>(R.id.selectModelButton)

        addMessage("Merhaba! Ben JARVIS. $helpText", isUser = false)
        if (!localLlm.isModelReady) {
            addMessage(
                "Serbest sohbet için bir yerel AI modeli seçmen gerekiyor. Yukarıdaki yükleme " +
                    "ikonuna dokunup, tarayıcından indirdiğin .litertlm model dosyasını seç.",
                isUser = false
            )
        }

        selectModelButton.setOnClickListener {
            modelPickerLauncher.launch(arrayOf("*/*"))
        }

        findViewById<ImageButton>(R.id.overlayToggleButton).setOnClickListener {
            toggleOverlayService()
        }
        findViewById<ImageButton>(R.id.overlayToggleButton).setOnLongClickListener {
            showHandleSizeDialog()
            true
        }

        voiceChangeButton.setOnClickListener {
            addMessage(speechManager.cycleVoice(), isUser = false)
        }

        sendButton.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserMessage(text)
            }
        }

        micButton.setOnClickListener { startVoiceInput() }
    }

    private fun showHandleSizeDialog() {
        val config = Config(this)
        val dialogView = layoutInflater.inflate(R.layout.dialog_handle_settings, null)

        val heightLabel = dialogView.findViewById<TextView>(R.id.handleHeightLabel)
        val heightSeekBar = dialogView.findViewById<SeekBar>(R.id.handleHeightSeekBar)
        val widthLabel = dialogView.findViewById<TextView>(R.id.handleWidthLabel)
        val widthSeekBar = dialogView.findViewById<SeekBar>(R.id.handleWidthSeekBar)
        val sideGroup = dialogView.findViewById<RadioGroup>(R.id.handleSideGroup)
        val leftOption = dialogView.findViewById<RadioButton>(R.id.sideLeftOption)
        val rightOption = dialogView.findViewById<RadioButton>(R.id.sideRightOption)

        heightLabel.text = "Boy (uzunluk): ${config.handleHeightDp}dp"
        heightSeekBar.progress = config.handleHeightDp - Config.MIN_HANDLE_HEIGHT_DP
        heightSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                heightLabel.text = "Boy (uzunluk): ${progress + Config.MIN_HANDLE_HEIGHT_DP}dp"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        widthLabel.text = "Kalınlık: ${config.handleWidthDp}dp"
        widthSeekBar.progress = config.handleWidthDp - Config.MIN_HANDLE_WIDTH_DP
        widthSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                widthLabel.text = "Kalınlık: ${progress + Config.MIN_HANDLE_WIDTH_DP}dp"
            }
            override fun onStartTrackingTouch(bar: SeekBar?) {}
            override fun onStopTrackingTouch(bar: SeekBar?) {}
        })

        if (config.handleOnRightSide) rightOption.isChecked = true else leftOption.isChecked = true

        AlertDialog.Builder(this)
            .setTitle("Çıkıntı ayarları")
            .setView(dialogView)
            .setPositiveButton("Kaydet") { _, _ ->
                config.handleHeightDp = heightSeekBar.progress + Config.MIN_HANDLE_HEIGHT_DP
                config.handleWidthDp = widthSeekBar.progress + Config.MIN_HANDLE_WIDTH_DP
                config.handleOnRightSide = sideGroup.checkedRadioButtonId == R.id.sideRightOption
                addMessage(
                    "Çıkıntı ayarlandı: ${config.handleHeightDp}dp boy, ${config.handleWidthDp}dp kalınlık, " +
                        (if (config.handleOnRightSide) "sağ kenar." else "sol kenar."),
                    isUser = false
                )
                ChatOverlayService.applyGeometry(this)
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun toggleOverlayService() {
        if (ChatOverlayService.isRunning) {
            ChatOverlayService.stop(this)
            addMessage("Kenar çıkıntısı kapatıldı.", isUser = false)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            addMessage(
                "Diğer uygulamaların üzerinde çıkıntı gösterebilmem için bir izin gerekiyor. " +
                    "Açılan ekrandan JARVIS'e izin ver.",
                isUser = false
            )
            overlayPermissionLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        ChatOverlayService.start(this)
        addMessage("Kenar çıkıntısı açıldı. Ekranın sağ kenarına bak. Boyunu değiştirmek için bu butona basılı tut.", isUser = false)
    }

    private fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun startVoiceInput() {
        if (!hasRecordAudioPermission()) {
            requestRuntimePermissions()
            return
        }
        orbView.setState(OrbView.State.LISTENING)
        speechManager.startListening(
            onResult = { text -> handleUserMessage(text) },
            onError = { err ->
                orbView.setState(OrbView.State.ERROR)
                addMessage(err, isUser = false)
                orbView.setState(OrbView.State.IDLE)
            }
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

    private fun handleUserMessage(text: String) {
        addMessage(text, isUser = true)
        orbView.setState(OrbView.State.THINKING)

        val normalized = text.trim().lowercase()
        if (normalized.contains("sesi değiştir") || normalized.contains("sesini değiştir") ||
            normalized.contains("ses değiştir")
        ) {
            val reply = speechManager.cycleVoice()
            addMessage(reply, isUser = false)
            orbView.setState(OrbView.State.IDLE)
            return
        }

        val localResult = LocalCommandParser.tryHandle(this, normalized)
        if (localResult != null) {
            addMessage(localResult, isUser = false)
            orbView.setState(OrbView.State.SPEAKING)
            speechManager.speak(localResult)
            orbView.setState(OrbView.State.IDLE)
            return
        }

        if (!localLlm.isModelReady) {
            val msg = "Bunu anlayamadım ve henüz yerel model seçilmedi. $helpText"
            addMessage(msg, isUser = false)
            orbView.setState(OrbView.State.IDLE)
            speechManager.speak("Bunu anlayamadım.")
            return
        }

        lifecycleScope.launch {
            val reply = localLlm.reply(systemPrompt, text)
            addMessage(reply, isUser = false)
            orbView.setState(OrbView.State.SPEAKING)
            speechManager.speak(reply)
            orbView.setState(OrbView.State.IDLE)
        }
    }

    private fun addMessage(text: String, isUser: Boolean) {
        adapter.addMessage(ChatMessage(text, isUser))
        findViewById<RecyclerView>(R.id.chatRecycler).scrollToPosition(messages.size - 1)
    }

    private fun requestRuntimePermissions() {
        val permissions = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CALENDAR,
            Manifest.permission.WRITE_CALENDAR,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needed = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toTypedArray(), permissionRequestCode)
        }
    }

    override fun onDestroy() {
        if (::speechManager.isInitialized) {
            speechManager.destroy()
        }
        super.onDestroy()
    }
}
