package com.jarvis.assistant.service

import android.annotation.SuppressLint
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.content.ContextCompat
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import kotlin.math.abs

/**
 * Small floating "bubble" that stays on top of other apps (YouTube, etc.),
 * similar to a chat head. Drag it anywhere on screen; a plain tap (no drag)
 * starts a single push-to-talk recording without switching away from
 * whatever app is currently open. Requires the "display over other apps"
 * permission, which MainActivity asks for before starting this service.
 */
class FloatingMicService : Service(), JarvisListenerService.JarvisEventListener {

    private var windowManager: WindowManager? = null
    private var bubbleView: ImageView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var jarvisService: JarvisListenerService? = null
    private var isBound = false

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val bound = (binder as JarvisListenerService.LocalBinder).getService()
            jarvisService = bound
            bound.addListener(this@FloatingMicService)
            isBound = true
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            jarvisService = null
            isBound = false
        }
    }

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        // Make sure the voice/AI service is (and stays) running in the background.
        ContextCompat.startForegroundService(this, Intent(this, JarvisListenerService::class.java))
        bindService(Intent(this, JarvisListenerService::class.java), connection, Context.BIND_AUTO_CREATE)
        addBubble()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val bubble = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setBackgroundResource(R.drawable.bg_floating_mic)
            val pad = (14 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
            setColorFilter(ContextCompat.getColor(this@FloatingMicService, R.color.jarvis_accent))
            contentDescription = getString(R.string.floating_mic_description)
        }
        bubbleView = bubble

        val size = (56 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size,
            size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 16
        params.y = 300
        layoutParams = params

        bubble.setOnTouchListener { view, event ->
            val p = layoutParams ?: return@setOnTouchListener false
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = p.x
                    initialY = p.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (abs(dx) > 12 || abs(dy) > 12) isDragging = true
                    p.x = initialX + dx.toInt()
                    p.y = initialY + dy.toInt()
                    windowManager?.updateViewLayout(view, p)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) onBubbleTapped()
                    true
                }
                else -> false
            }
        }

        try {
            windowManager?.addView(bubble, params)
        } catch (e: Exception) {
            // Overlay permission missing or window token problem — stop quietly
            // rather than crash the whole app.
            stopSelf()
        }
    }

    private fun onBubbleTapped() {
        val bound = jarvisService
        if (bound == null) {
            // Not connected yet — open the app instead of silently failing.
            startActivity(
                Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        bound.pushToTalk()
    }

    // --- Visual feedback so the bubble shows what's happening, even while
    //     another app (e.g. YouTube) is in the foreground. ---

    override fun onUserSpeech(text: String) {}
    override fun onAssistantReply(text: String) {}

    override fun onListeningStateChanged(listening: Boolean) = setBubbleActive(listening)

    override fun onSpeakStateChanged(speaking: Boolean) = setBubbleActive(speaking)

    private fun setBubbleActive(active: Boolean) {
        val bubble = bubbleView ?: return
        val colorRes = if (active) R.color.jarvis_accent else R.color.jarvis_text_dim
        bubble.setColorFilter(ContextCompat.getColor(this, colorRes))
        bubble.animate()
            .scaleX(if (active) 1.15f else 1f)
            .scaleY(if (active) 1.15f else 1f)
            .setDuration(150)
            .start()
    }

    override fun onDestroy() {
        isRunning = false
        try {
            jarvisService?.removeListener(this)
            if (isBound) unbindService(connection)
        } catch (e: Exception) { /* ignore */ }
        try {
            bubbleView?.let { windowManager?.removeView(it) }
        } catch (e: Exception) { /* ignore */ }
        super.onDestroy()
    }

    companion object {
        @Volatile
        var isRunning: Boolean = false
            private set
    }
}
